﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary1;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
      Random rnd = new Random();
      public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
         listBox1.Items.Clear();
         Class1.compl[] mas = new Class1.compl[10];
         string str;
         for (int i = 0; i < 2; i++)
         {
            mas[i].ch= rnd.Next(1, 10);
            mas[i].zn = rnd.Next(1, 10);
            str = mas[i].Chislo();
            listBox1.Items.Add(str);
         }
         str = Class1.Sum(mas[0], mas[1]).Chislo();

         listBox1.Items.Add("результат сложения "+str);
      }

      private void Button2_Click(object sender, EventArgs e)
      {
         listBox1.Items.Clear();
         Class1.compl[] mas = new Class1.compl[10];
         string str;
         for (int i = 0; i < 2; i++)
         {
            mas[i].ch = rnd.Next(1, 10);
            mas[i].zn = rnd.Next(1, 10);
            str = mas[i].Chislo();
            listBox1.Items.Add(str);
         }
         str = Class1.rrr(mas[0], mas[1]).Chislo();

         listBox1.Items.Add("результат вычитания " + str);
      }

      private void Button3_Click(object sender, EventArgs e)
      {
         listBox1.Items.Clear();
         Class1.compl[] mas = new Class1.compl[10];
         string str;
         for (int i = 0; i < 2; i++)
         {
            mas[i].ch = rnd.Next(1, 10);
            mas[i].zn = rnd.Next(1, 10);
            str = mas[i].Chislo();
            listBox1.Items.Add(str);
         }
         str = Class1.umn(mas[0], mas[1]).Chislo();

         listBox1.Items.Add("результат умножения " + str);
      }

      private void Button4_Click(object sender, EventArgs e)
      {
         listBox1.Items.Clear();
         Class1.compl[] mas = new Class1.compl[10];
         string str;
         for (int i = 0; i < 2; i++)
         {
            mas[i].ch = rnd.Next(1, 10);
            mas[i].zn = rnd.Next(1, 10);
            str = mas[i].Chislo();
            listBox1.Items.Add(str);
         }
         str = Class1.ded(mas[0], mas[1]).Chislo();

         listBox1.Items.Add("результат деления " + str);
      }

      private void Button5_Click(object sender, EventArgs e)
      {
         listBox1.Items.Clear();
         Class1.compl[] mas = new Class1.compl[10];
         string str;
         for (int i = 0; i < 1; i++)
         {
            mas[i].ch = rnd.Next(1, 10);
            mas[i].zn = rnd.Next(1, 10);
            str = mas[i].Chislo();
            listBox1.Items.Add(str);
         }
         str = Class1.sokr(mas[0], mas[1]).Chislo();
         listBox1.Items.Add("результат сокращения " + str);
      }

      private void Button6_Click(object sender, EventArgs e)
      {
         listBox1.Items.Clear();
         Class1.compl[] mas = new Class1.compl[10];
         string str;
         for (int i = 0; i < 1; i++)
         {
            mas[i].ch = rnd.Next(1, 10); 
            mas[i].zn = rnd.Next(1, 10);
            str = mas[i].Chislo();
            listBox1.Items.Add(str);
         }
         str = Class1.vid(mas[0], mas[1]).Chislo();
         str = str.Trim();
         string[] b = str.Split(',');
         
         string s = Convert.ToString(b[0]);
         char[] a = s.ToCharArray();
         char v = ' ';
         for (int j = 0; j < a.Length; j++)
         {
            if (a[j] == '/')
            {
               v = a[j - 1];
               listBox1.Items.Add("результат выделения целой части "+v);
               break;
            }
         }
         if(v==' ')
         {
            listBox1.Items.Add("результат выделения целой части "+b[0]);
         }        
      }

      private void Button7_Click(object sender, EventArgs e)
      {
         listBox1.Items.Clear();
         Class1.compl[] mas = new Class1.compl[10];
         string str;
         string st;
         for (int i = 0; i < 2; i++)
         {
            mas[i].ch = rnd.Next(1, 10);
            mas[i].zn = rnd.Next(1, 10);
            str = mas[i].Chislo();
            listBox1.Items.Add(str);
         }
         str = Class1.log(mas[0], mas[1]).Chislo();
         if (str[0]== '0')
         {
            listBox1.Items.Add("дроби равны");
         }
         else if(str[0] != '-')
         {
            listBox1.Items.Add("дробь " + Convert.ToString(mas[0].Chislo()) + " больше");
         }
         if (str[0] == '-')
         {
            listBox1.Items.Add("дробь " + mas[0].Chislo() + " меньше");
         }
      }

      private void Button8_Click(object sender, EventArgs e)
      {
         listBox1.Items.Clear();
         Class1.compl[] mas = new Class1.compl[10];
         string str;
         for (int i = 0; i < 4; i++)
         {
            mas[i].ch = rnd.Next(1, 10);
            mas[i].zn = rnd.Next(1, 10);
            str = mas[i].Chislo();
            listBox1.Items.Add(str);
         }
         Class1.compl max=mas[0];
         Class1.compl min=mas[0];
         int j = 0;
         for (int i = 1; i < 4; i++)
         {
            str = Class1.log(mas[j], mas[i]).Chislo();
            if (str[0] != '-')
            {
               min = mas[i];
               j = i;
            }
         }
         j = 0;
         for (int i = 1; i < 4; i++)
         {
            str = Class1.log(mas[j], mas[i]).Chislo();
            if (str[0] == '-')
            {
               max = mas[i];
               j = i;
            }
         }
         listBox1.Items.Add("Минимальный элемент "+min.Chislo());
         listBox1.Items.Add("Максимальный элемент " + max.Chislo());
         str = Class1.rrr(max, min).Chislo();
         listBox1.Items.Add("результат вычитания " + str);
      }
   }
   }
   
