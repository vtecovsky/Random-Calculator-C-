﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Class1
    {
      public struct compl
      {
         public double ch;
         public double zn;
         public string Chislo()
         {
            return ch.ToString() + "/" + zn.ToString();
         }
      }
      public static compl Sum(compl a, compl b)
      {
         compl c;
         double v;
         double d;
         if (a.zn != b.zn)
         {
            c.zn = a.zn* b.zn;
            v = c.zn / a.zn;
            d= c.zn / b.zn;
            a.ch = a.ch* v;
            b.ch = b.ch * d;
            c.ch = a.ch + b.ch;
            c.zn = a.zn * b.zn;
         }
         else
         {
            c.ch = a.ch + b.ch;
            c.zn = a.zn;
         }
         return c;
      }
      public static compl rrr(compl a, compl b)
      {
         compl c;
         double v;
         double d;
         if (a.zn != b.zn)
         {
            c.zn = a.zn * b.zn;
            v = c.zn / a.zn;
            d = c.zn / b.zn;
            a.ch = a.ch * v;
            b.ch = b.ch * d;
            c.ch = a.ch - b.ch;
            c.zn = a.zn * b.zn;
         }
         else
         {
            c.ch = a.ch - b.ch;
            c.zn = a.zn;
         }
         return c;
      }
      public static compl umn(compl a, compl b)
      {
         compl c;
            c.zn = a.zn * b.zn;
            c.ch = a.ch * b.ch;
         return c;
      }
      public static compl ded(compl a, compl b)
      {
         compl c;
         c.zn = a.zn * b.ch;
         c.ch = a.ch * b.zn;
         return c;
      }
      public static compl sokr(compl a, compl b)
      {
         compl c;
         compl d;
         c.ch = a.ch;
         c.zn = a.zn;
         for(int i = 1; i <= c.zn; i++)
         {
            if (c.ch % i == 0 && c.zn % i == 0)
            {
               c.ch /= i;
               c.zn /= i;
               i = 1;
            }
         }
         d.ch = b.ch;
         d.zn = b.zn;
         for (int i = 1; i <= d.zn; i++)
         {
            if (d.ch % i == 0 && d.zn % i == 0)
            {
               d.ch /= i;
               d.zn /= i;
               i = 1;
            }
         }
         return c;
      }
      public static compl vid(compl a, compl b)
      {
         compl c;
         c.ch= a.ch / a.zn;
         c.zn = a.ch / a.zn;
         return c;
      }
      public static compl log(compl a, compl b)
      {
         compl c;
         double v;
         double d;
         c = rrr(a, b);
         return c;


      }
   }
}
